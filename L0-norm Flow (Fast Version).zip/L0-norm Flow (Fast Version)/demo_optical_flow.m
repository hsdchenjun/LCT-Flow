
close all;
clear;


%I1 = double(imread('data/RubberWhale_frame10.png'))/255;
%I2 = double(imread('data/RubberWhale_frame11.png'))/255;
I1 = double(imread('data/RubberWhale_illumination_10.png'))/255;
I2 = double(imread('data/RubberWhale_illumination_11.png'))/255;


flowPath = 'GroundTruth/RubberWhale/flow10.flo';
% parameter settings
 st = parameter_settings();
 
  st.lambda = 0.001;% the weight to control the number of the preserved non-zero flow graidents
  st.alpha = 0.05; % the weight of the regularization term
  st.pyramid_factor = 0.5; % rescalling settings
  st.warps = 5; % the numbers of warps per level
  st.max_its = 5; % the number of equation iterations per warp

show_flow =1; % 1 = display the evolution of the flow, 0 = do not show
h = figure('Name', 'Optical flow');
tic
[flow] = coarse_to_fine(I1, I2, st, show_flow, h);
toc
u = flow(:, :, 1);
v = flow(:, :, 2);
realFlow = readFlowFile(flowPath);
tu = realFlow(:, :, 1);
tv = realFlow(:, :, 2);
Gtflow = uint8(robust_flowToColor(realFlow));
figure('Name', 'Ground Truth'); imshow(Gtflow);
% compute the mean end-point error (mepe) and the mean angular error (mang)
UNKNOWN_FLOW_THRESH = 1e9;
[mang, mepe] = flowError(tu, tv, u, v, ...
   0, 0.0, UNKNOWN_FLOW_THRESH);
disp(['Mean end-point error: ', num2str(mepe)]);
disp(['Mean angular error: ', num2str(mang)]);

% display the flow
flowImg = uint8(robust_flowToColor(flow));
figure('Name', 'Predicted flow field'); imshow(flowImg);
